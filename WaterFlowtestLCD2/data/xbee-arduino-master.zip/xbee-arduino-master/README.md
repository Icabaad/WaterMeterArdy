# xbee-arduino

Arduino library for communicating with XBees in API mode, with support for both Series 1 (802.15.4) and Series 2 (ZB Pro/ZNet). This library Includes support for the majority of packet types, including: TX/RX, AT Command, Remote AT, I/O Samples and Modem Status. This was originally on googlecode and now github. I will attempt to keep both repos in sync. See https://code.google.com/p/xbee-arduino/ for documentation 
